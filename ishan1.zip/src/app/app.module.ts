import {HttpClientModule} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {DetailService} from './Services/detail-services';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {RechargeDisplayComponent} from './DisplayComponent/displaydetails.component';
import {SearchRechargeComponent} from './SeachComponent/searchdetails.component';
import {RechargePipe} from './Pipe/Details.Pipe';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    RechargeDisplayComponent,
    RechargePipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [DetailService],
  bootstrap: [AppComponent]
})
export class AppModule { }

