export interface IDetails{
    ProjectID:number;
    ProjectName:string;
    Domain:string;
    ProjectManager:string;    
    Location:string;   
    Cost:number;
}
