import { Component, OnInit } from '@angular/core';
import { DetailService } from '../Services/detail-services';
import { IDetails } from '../Models/ProjectDetail';
import {FormBuilder,FormGroup} from '@angular/forms';

@Component({
  selector: 'app-recharge-display',
  templateUrl: 'display-searchdetails.component.html',
  styleUrls: ['displaydetails.component.css']
})
export class RechargeDisplayComponent implements OnInit {
  details:IDetails[];
  submitted:Boolean=false;
  
  constructor(private recservice:DetailService,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.getAll();
  }
  getAll(){
    this.recservice.getDetails().subscribe(data=>{
        this.details=data;});

}

onSubmit(){
  this.submitted=true;
  this.recservice.getDetails().subscribe(data=>{
      this.details=data;
  
  }) 
 
}
txtchanged(){
  this.submitted=false;
}
}
