import { Component, OnInit } from '@angular/core';
import { DetailService } from '../Services/detail-services';
import {FormBuilder,FormGroup} from '@angular/forms';
import { IDetails } from '../Models/ProjectDetail';

@Component({
  selector: 'app-search-recharge',
  templateUrl: 'searchdetails.component.html',
  styleUrls: ['searchdetails.component.css']
})
export class SearchRechargeComponent implements OnInit {
  details:IDetails[];
  submitted:Boolean=false;

  constructor(private recservice:DetailService,private formBuilder:FormBuilder) { }

  ngOnInit() {
  }
  
  onSubmit(){
    this.submitted=true;
    this.recservice.getDetails().subscribe(data=>{
        this.details=data;
    }) 
   
  }
  txtchanged(){
    this.submitted=false;
  }
}
