import {Injectable,OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {IDetails} from '../Models/ProjectDetail';

@Injectable()
export class DetailService implements OnInit{

    url:string="/assets/Project.json";
    ngOnInit(): void{
        this.getDetails();
    }
    constructor(private _http:HttpClient){

    }

    getDetails(){return this._http.get<IDetails[]>(this.url);}
}