import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'filter'
})
export class RechargePipe implements PipeTransform{
    transform(details: any[], mobileNumber:string):any[] {
        if(!details){
            return [];
        }
        if(!mobileNumber){
            return details;
        }
        return details.filter(dt=>{ return dt.Domain==mobileNumber;})
    }
    
}