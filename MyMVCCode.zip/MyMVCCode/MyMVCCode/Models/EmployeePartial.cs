﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyMVCCode.Models
{
    [System.ComponentModel.DataAnnotations.MetadataType(typeof(EmployeeMetaData))]
    public partial class Employee_46003297_4
    {

    }
}