﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace MyMVCCode.Infrastructure
{
    public class ProfileAllAttribute : FilterAttribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            FileStream objFS = new FileStream(@"d:LogFileForAction.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objSW = new StreamWriter(objFS);
            objSW.WriteLine("--------OnActionExecuted--------");
            string strBrowserName = filterContext.HttpContext.Request.Browser.Browser;

            System.Web.Routing.RouteData objRD = filterContext.HttpContext.Request.RequestContext.RouteData;
            System.Web.Routing.RouteValueDictionary objRVD = objRD.Values;
            string strController = objRVD["controller"] as string;
            string strAction = objRVD["action"] as string;
            objSW.WriteLine($"Browser: {strBrowserName}, Encoding used: {filterContext.HttpContext.Request.ContentEncoding.EncodingName}, Controller: {strController} - Action: {strAction}");
            objSW.WriteLine("------------------------");
            objSW.Flush();
            objSW.Close();
            objSW.Close();
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            FileStream objFS = new FileStream(@"d:LogFileForAction.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objSW = new StreamWriter(objFS);
            objSW.WriteLine("--------OnActionExecuting--------");
            objSW.WriteLine($"AnonymousID: {filterContext.HttpContext.Request.AnonymousID},HTTPMethod used: {filterContext.HttpContext.Request.HttpMethod}, DateTime: {DateTime.Now.ToLongDateString()}");
            objSW.WriteLine("----------------------------");
            objSW.Flush();
            objSW.Close();
            objFS.Close();
        }
    }
}