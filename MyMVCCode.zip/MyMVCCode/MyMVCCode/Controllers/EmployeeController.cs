﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyMVCCode.Models;
using System.Data.Entity;
using System.Net;
using MyMVCCode.Infrastructure;

namespace MyMVCCode.Controllers
{
    public class EmployeeController : Controller
    {
        private Training_13Aug19_PuneEntities db = new Training_13Aug19_PuneEntities();
        // GET: Employee
        //[ProfileAll()]
        public ActionResult Index()
        {
            var employees = db.Employee_46003297_4.Include(e => e.Department_46003297).Include(e => e.Designation_46003297);
            return View(employees.ToList());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Employee_46003297_4 employee = db.Employee_46003297_4.Find(id);
            if (employee == null)
            { return HttpNotFound(); }
            return View(employee);
        }

        public ActionResult Create()
        {
            ViewBag.Department = new SelectList(db.Department_46003297, "ID", "Name");
            ViewBag.Designation = new SelectList(db.Designation_46003297, "ID", "Name");
            return View();
        }

        [HttpPost]
        public ActionResult Create([Bind(Include = "ID,Name,Designation,Department")] Employee_46003297_4 employee)
        {
            if (ModelState.IsValid)
            {
                db.Employee_46003297_4.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Department = new SelectList(db.Department_46003297, "ID", "Name", employee.Department);
            ViewBag.Designation = new SelectList(db.Designation_46003297, "ID", "Name", employee.Designation);
            return View(employee);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            { return new HttpStatusCodeResult(HttpStatusCode.BadRequest); }
            Employee_46003297_4 employee = db.Employee_46003297_4.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            ViewBag.Department = new SelectList(db.Department_46003297, "ID", "Name", employee.Department);
            ViewBag.Designation = new SelectList(db.Designation_46003297, "ID", "Name", employee.Designation);
            return View(employee);
        }

        [HttpPost]
        public ActionResult Edit([Bind(Include = "ID,Name,Designation,Department")] Employee_46003297_4 employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Department = new SelectList(db.Department_46003297, "ID", "Name", employee.Department);
            ViewBag.Designation = new SelectList(db.Designation_46003297, "ID", "Name", employee.Designation);
            return View(employee);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_46003297_4 employee = db.Employee_46003297_4.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }
 
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_46003297_4 employee = db.Employee_46003297_4.Find(id);
            db.Employee_46003297_4.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}