import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DisplayComponent } from './Display/Display.component'
import { HttpClientModule } from '@angular/common/http';
import { ProjectService } from './../app/Project.service';
import { ProjectFilter } from './../app/Pipe/PipeFilter'
@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    ProjectFilter
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ProjectService],
  bootstrap: [AppComponent]
})
export class AppModule { }
