import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { IProject } from './../app/Project';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
@Injectable()
export class ProjectService
{
    private _url:string = "/assets/Data/Project.json";
    constructor(private http:HttpClient)
    {
    };
    getProject():Observable<IProject[]>
    {
    return this.http.get<IProject[]>(this._url);
    }
}
