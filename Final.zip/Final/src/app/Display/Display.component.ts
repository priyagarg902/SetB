import { OnInit, Component } from '@angular/core';
import { ProjectService } from './../Project.service';
import { IProject } from './../Project';
import {FormBuilder,FormGroup} from '@angular/forms';

@Component({
    selector:"Display",
    templateUrl:'./Display.component.html',
    styleUrls: ['./Display.component.css']
})
export class DisplayComponent implements OnInit
{
    List:IProject[];
    submitted:boolean = false;
    ngOnInit(): void
    {
        this.getAll();
    }
    constructor(private empservice:ProjectService,private formBuilder:FormBuilder)
    {
    }
    getAll()
    {
        this.empservice.getProject().subscribe(data=>{this.List=data;});
    }
    onSubmit()
    {
        this.submitted=true;
        this.empservice.getProject().subscribe(data=>{this.List=data;})   
    }
    txtchanged()
    {
        this.submitted=false;
    }
}