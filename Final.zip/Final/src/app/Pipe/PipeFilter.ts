import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'filter'
})
export class ProjectFilter implements PipeTransform{
    transform(List: any[], d:string):any[] {
        if(!List){
            return [];
        }
        if(!d){
            return ["No Project Found"];
        }
        return List.filter(dt=>{ return dt.Domain==d;})
    }
}