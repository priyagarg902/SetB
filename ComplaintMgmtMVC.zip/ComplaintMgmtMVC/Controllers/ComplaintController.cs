﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using ComplaintMgmtMVC.Models;

namespace ComplaintMgmtMVC.Controllers
{
    public class ComplaintController : Controller
    {
        private ComplaintMgmtEntities db = new ComplaintMgmtEntities();
        // GET: Complaint
        public ActionResult Index()
        {
            var complaints = db.ComplaintTable_46004317;
            return View(complaints.ToList());
        }
        // GET: /Employee/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ComplaintTable_46004317 complaint= db.ComplaintTable_46004317.Find(id);
            if (complaint == null)
            {
                return HttpNotFound();
            }
            return View(complaint);
        }
    }
}