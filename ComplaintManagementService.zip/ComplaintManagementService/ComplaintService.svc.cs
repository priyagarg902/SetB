﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ComplaintManagementService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class ComplaintService : IComplaintService
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Complaintconn"].ConnectionString);
        SqlCommand cmd;
        SqlDataReader dr;

        public bool AddComplaint(Complaint complaint)
        {
            bool complaintAdded = false;

            try
            {
                cmd = new SqlCommand("InsertComplaint_46004317", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductType", complaint.ProductType);
                cmd.Parameters.AddWithValue("@ModelNo", complaint.ModelNo);
                cmd.Parameters.AddWithValue("@DateofPurchase", complaint.DateofPurchase);
                cmd.Parameters.AddWithValue("@CustomerName", complaint.CustomerName);
                cmd.Parameters.AddWithValue("@ContactNo", complaint.ContactNo);
                cmd.Parameters.AddWithValue("@EmailAddress", complaint.EmailAddress);
                cmd.Parameters.AddWithValue("@Description", complaint.Description);

                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                    complaintAdded = true;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return complaintAdded;
        }
    }
}
