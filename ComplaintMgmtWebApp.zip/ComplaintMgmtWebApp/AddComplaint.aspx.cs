﻿using ComplaintMgmtWebApp.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ComplaintMgmtWebApp
{
    public partial class AddComplaint : System.Web.UI.Page
    {
        ComplaintServiceClient client = new ComplaintServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddComplaint_Click(object sender, EventArgs e)
        {
            try
            {
                Complaint complaint = new Complaint();

                complaint.ProductType = ddlProductType.SelectedValue;
                complaint.ModelNo = Convert.ToInt32(txtModelNo.Text);
                complaint.DateofPurchase = Convert.ToDateTime(txtDateofPurchase.Text);
                complaint.CustomerName = txtCustomerName.Text;
                complaint.ContactNo = Convert.ToDouble(txtContactNo.Text);
                complaint.EmailAddress = txtEmailAddress.Text;
                complaint.Description = txtDescription.Text;


                bool status = client.AddComplaint(complaint);

                if (status)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "m1", "alert('Complaint Registered Successfully')", true);
                    txtModelNo.Text = "";
                    txtDateofPurchase.Text = "";
                    txtCustomerName.Text = "";
                    txtContactNo.Text = "";
                    txtEmailAddress.Text = "";
                    txtDescription.Text = "";                  
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "error5", "alert('" + ex.Message + "')", true);
                //throw ex;
            }
        }
    }
}